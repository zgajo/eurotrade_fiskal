<?php

session_start();

require 'baza/konekcija.php';
require 'baza/fisk_kupac.php';
require 'search.php';
require 'baza/fisk_intervencija.php';



?>

