<header>
    <div class="header">
        <div class="header-top">
            <a href="index.php"><h1>Eurotrade fiskalizacija</h1></a>
            <ul>
                <li><a href="kupci.php"><span>Kupci</span></a></li>
                <li><a href="intervencije.php"><span>Intervencije</span></a></li>
                <li><a href="upute.php"><span>Uputstva</span></a></li>
            </ul>
        </div>
        <div class="header-img"><img src="images/header.jpg" alt="" height="225" width="899"></div>
    </div>
</header>