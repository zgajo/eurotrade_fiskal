<header>
    <div class="header">
        <div class="header-top">
            <a href="index.php"><h1>Eurotrade fiskalizacija</h1></a>
            <ul>
                <li><a href="kupci.php"><span>Kupci</span></a></li>
                <li><a href="intervencije.php"><span>Intervencije</span></a></li>
                <li><a href="ugovori.php"><span>Ugovori</span></a></li>
            </ul>
        </div>
        
    </div>
</header>