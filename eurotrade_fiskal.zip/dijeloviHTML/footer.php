<footer>
    <div class="footer">
        <div class="footer-left">
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            <p><strong>Kontakt info</strong></p>
            <p>&nbsp;</p>
            <p>
                ROVINJ, Naselje Gripole 53/C, <br>tel. 052/803-699, fax 052/830-430<br>
                Servis: 052/830-693
            </p>
        </div>
        <div class="footer-right">
            <ul>
                <li><a href="index.php">Početna</a>/</li>
                <li><a href="#">Intervencije</a>/</li>
                <li><a href="#">Upute</a></li>

            </ul>

            <img src="images/footnote.gif" class="copyright" alt="htmltemplates.net"></a>
            <p>&copy; Copyright 2014. Dizajn: <a class="footer-link" target="_blank" href="#">Darko Pranjić</a>
                <!--DO NOT Remove The Footer Links-->
            </p>
        </div>
    </div>
</footer>