<div class="sections">
    <div class="section1">
        <h3>Kupci</h3>
        <p>&nbsp;</p>
        <p>Status ugovora/
            kupci<br>
            Novi kupac<br>
            Izrada novog ugovora
        </p>
        <p>&nbsp;</p>
        <p><a href="ugovori.php" class="more">Više</a></p>
    </div>
    <div class="section2">
        <h3>Intervencije</h3>
        <p>&nbsp;</p>
        <p>Sve intervencije i izrada novih<br>
        </p>
        <p>&nbsp;</p>
        <p><a href="intervencije.php" class="more">Više</a></p>
    </div>
    <div class="section3">
        <h3>Postavljanje kase u rad</h3>
        <p>&nbsp;</p>
        <p>Instrukcije postavljanja kase u rad i najčešći problemi koji se javljaju na kasi<br>
        </p>
        <p>&nbsp;</p>
        <p><a href="files.php" class="more">Više</a></p>
    </div>
    <div class="section4">
        <h3>Uputstva za kupca</h3>
        <p>&nbsp;</p>
        <p>Kratke upute made by: Njićpra<br>
            Upute od digitrona
        </p>
        <p>&nbsp;</p>
        <p><a href="#" class="more">Više</a></p>
    </div>
</div>