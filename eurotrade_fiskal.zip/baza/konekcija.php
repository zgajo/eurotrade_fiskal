<?php
#mysql_connect('localhost','root','dpranjic') or die('nemoguće povezati na bazu');
#mysql_select_db('fiskalizacija') or die('nemoguće povezati na tabele');
mysql_connect('mysql13.000webhost.com','a4230630_euro','casino12') or die('nemoguće povezati na bazu');
mysql_select_db('a4230630_euro') or die('nemoguće povezati na tabele');
mysql_query('SET CHARACTER SET utf8');
mysql_query('SET CHARACTER utf8mb4');

?>
